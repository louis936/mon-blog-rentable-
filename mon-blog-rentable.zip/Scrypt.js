// Script pour interactions éventuelles, pour l'instant, un simple message dans la console
console.log("Bienvenue sur Mon Blog Rentable !");